import argparse
import os
import glob
import platform
import sys
from pathlib import Path
import torch
import time

FILE = Path(__file__).resolve()
ROOT = FILE.parents[0]  # YOLO root directory
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))  # add ROOT to PATH
ROOT = Path(os.path.relpath(ROOT, Path.cwd()))  # relative

from models.common import DetectMultiBackend
from utils.dataloaders import IMG_FORMATS, VID_FORMATS, LoadImages, LoadStreams
from utils.general import LOGGER, Profile, check_file, check_img_size, check_imshow, colorstr, cv2, increment_path, non_max_suppression
from utils.torch_utils import select_device, smart_inference_mode

@smart_inference_mode()
def run(
        weights=['yolov9-e.pt' for w in range(8)],  # model paths
        source='/root/servers/IMV_SEMANTIC_SEARCH_YOLO_SERVER/INDEX/index_hetz4/output/INDEX/hetz1_index/video/POE-Selina-Cetate-2-20240926171425-20240926171642',  # file/dir/URL/glob/screen/0(webcam)
        imgsz=(640, 640),  # inference size (height, width)
        conf_thres=0.25,  # confidence threshold
        iou_thres=0.45,  # NMS IOU threshold
        max_det=50,  # maximum detections per image
        device='0',  # cuda device, i.e. 0 or 0,1,2,3 or cpu
        view_img=False,  # show results
        save_txt=False,  # save results to *.txt
        save_conf=False,  # save confidences in --save-txt labels
        save_crop=False,  # save cropped prediction boxes
        nosave=False,  # do not save images/videos
        classes=0,  # filter by class: --class 0, or --class 0 2 3
        agnostic_nms=False,  # class-agnostic NMS
        augment=False,  # augmented inference
        project=ROOT / 'runs/detect',  # save results to project/name
        name='exp',  # save results to project/name
):
    source = str(source)

    # Check if the source is a directory or a file
    if os.path.isdir(source):
        # If it's a folder, use glob to get all .jpg, .jpeg, and .png files recursively
        source_files = glob.glob(f"{source}/**/*.jpg", recursive=True) + \
                    glob.glob(f"{source}/**/*.jpeg", recursive=True) + \
                    glob.glob(f"{source}/**/*.png", recursive=True)
    elif os.path.isfile(source):
        # If it's a single file, wrap it in a list
        source_files = [source]
    else:
        # Handle the case where the source is neither a file nor a directory
        raise ValueError(f"Source {source} is neither a valid file nor a valid directory.")

    # Optionally save inference images
    save_img = [x for x in source_files]
    # is_file = Path(source).suffix[1:] in (IMG_FORMATS + VID_FORMATS)
    # is_url = source.lower().startswith(('rtsp://', 'rtmp://', 'http://', 'https://'))
    # webcam = source.isnumeric() or source.endswith('.txt') or (is_url and not is_file)

    # Directories
    save_dir = increment_path(Path(project) / name, exist_ok=True)  # increment run
    (save_dir / 'labels' if save_txt else save_dir).mkdir(parents=True, exist_ok=True)  # make dir

    # Load model
    # device = select_device(device)
    # models = [DetectMultiBackend(w, device=device) for w in weights]  # Load all 8 models
    stride, names, pt = models[0].stride, models[0].names, models[0].pt
    imgsz = check_img_size(imgsz, s=stride)  # check image size


    # Dataloader
    dataset = LoadImages(source_files, img_size=imgsz, stride=stride, auto=pt)
    print(len(dataset))
    bs = len(dataset)

    # Run inference on each image or video frame
    for path, im, im0s, _, _ in dataset:
        imos_resized = cv2.resize(im0s, (640,340))
        print(imos_resized.shape)
        im = torch.from_numpy(im).to(device)
        im = im.half() if models[0].fp16 else im.float()  # uint8 to fp16/32
        im /= 255  # normalize image
        if len(im.shape) == 3:
            im = im[None]  # add batch dimension

        # Perform inference with each model
        pred_all = []
        start_time = time.time()
        for model in models:  # Sequential inference on all models
            pred = model(im)
            pred = non_max_suppression(pred, conf_thres, iou_thres, classes, agnostic_nms, max_det=max_det)
            pred_all.append(pred)

        # Process predictions from all models
        for i, det in enumerate(pred_all):  # per model
            if len(det):
                for *xyxy, conf, cls in reversed(det[0]):  # process first model's detections
                    label = f'{names[int(cls)]} {conf:.2f}'
                    cv2.rectangle(imos_resized, (int(xyxy[0]), int(xyxy[1])), (int(xyxy[2]), int(xyxy[3])), (255, 0, 0), 2)
                    cv2.putText(imos_resized, label, (int(xyxy[0]), int(xyxy[1]) - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 0, 0), 2)

        LOGGER.info(f"Processed {path} in {time.time() - start_time:.3f}s")

        # Show results
        if view_img:
            cv2.imshow(path, im)
            cv2.waitKey(1)  # 1 millisecond

        # Save results
        if save_img:
            cv2.imwrite(str(save_dir / path.split('/')[-1].replace('.img.img', '.img')), imos_resized)
    LOGGER.info(f'Results saved to {save_dir}')
    LOGGER.info(f"PROCESSED IN {time.time() - start_time} s")

def parse_opt():
    parser = argparse.ArgumentParser()
    parser.add_argument('--weights', nargs='+', type=str, default=['yolov9-e.pt' for w in range(8)], help='model paths')
    parser.add_argument('--source', type=str, default='/root/servers/IMV_SEMANTIC_SEARCH_YOLO_SERVER/INDEX/index_hetz4/output/INDEX/hetz1_index/', help='file/dir/URL/glob/screen/0(webcam)')
    parser.add_argument('--imgsz', '--img', '--img-size', nargs='+', type=int, default=(640, 640), help='inference size h,w')
    parser.add_argument('--conf-thres', type=float, default=0.25, help='confidence threshold')
    parser.add_argument('--iou-thres', type=float, default=0.45, help='NMS IoU threshold')
    parser.add_argument('--max-det', type=int, default=1000, help='maximum detections per image')
    parser.add_argument('--device', default='0', help='cuda device, i.e. 0 or 0,1,2,3 or cpu')
    parser.add_argument('--view-img', action='store_true', help='show results')
    parser.add_argument('--save-txt', action='store_true', help='save results to *.txt')
    parser.add_argument('--save-conf', action='store_true', help='save confidences in --save-txt labels')
    parser.add_argument('--save-crop', action='store_true', help='save cropped prediction boxes')
    parser.add_argument('--nosave', action='store_true', help='do not save images/videos')
    parser.add_argument('--classes', nargs='+', type=int, help='filter by class: --classes 0, or --classes 0 2 3')
    parser.add_argument('--agnostic-nms', action='store_true', help='class-agnostic NMS')
    parser.add_argument('--augment', action='store_true', help='augmented inference')
    parser.add_argument('--project', default=ROOT / 'runs/detect', help='save results to project/name')
    parser.add_argument('--name', default='exp', help='save results to project/name')
    opt = parser.parse_args()
    return opt


if __name__ == '__main__':
    opt = parse_opt()
    run(**vars(opt))
